create procedure insert_equity_share(p_equity equity_shares%rowtype) is
begin
    insert into equity_shares
    values p_equity;
end;
/

