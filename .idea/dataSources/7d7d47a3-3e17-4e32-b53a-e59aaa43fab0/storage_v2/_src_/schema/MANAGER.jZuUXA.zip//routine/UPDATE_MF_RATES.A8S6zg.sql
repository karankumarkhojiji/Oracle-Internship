create procedure update_mf_rates(p_mf_rates in mf_rates%rowtype) is
begin
    update mf_rates
    set mf_id     = p_mf_rates.mf_id,
        rate_date = p_mf_rates.rate_date,
        nav       = p_mf_rates.nav
    where rate_id = p_mf_rates.rate_id;
end;
/

