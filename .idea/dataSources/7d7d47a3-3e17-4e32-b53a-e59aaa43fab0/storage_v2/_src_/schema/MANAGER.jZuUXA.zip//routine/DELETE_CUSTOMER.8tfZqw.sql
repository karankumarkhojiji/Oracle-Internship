create procedure delete_customer(p_customer_id in customers.customer_id%type) is
begin
    delete
    from customers
    where customer_id = p_customer_id;
end;
/

