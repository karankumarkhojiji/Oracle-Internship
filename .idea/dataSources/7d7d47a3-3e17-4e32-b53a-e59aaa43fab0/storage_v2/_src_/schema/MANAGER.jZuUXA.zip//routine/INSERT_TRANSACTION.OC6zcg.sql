create procedure insert_transaction(p_transaction in transactions%rowtype) is
begin
    insert into transactions values p_transaction;
end;
/

