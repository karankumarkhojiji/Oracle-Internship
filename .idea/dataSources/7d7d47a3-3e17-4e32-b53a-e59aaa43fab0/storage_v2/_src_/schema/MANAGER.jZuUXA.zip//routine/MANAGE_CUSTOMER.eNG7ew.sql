create procedure manage_customer(p_operation in varchar2, p_customer customers%rowtype) is
begin
    if p_operation = 'insert' then
        insert into customers
        values p_customer;
    elsif p_operation = 'update' then
        update customers
        set first_name   = p_customer.first_name,
            last_name    = p_customer.last_name,
            email        = p_customer.email,
            phone_number = p_customer.phone_number,
            address      = p_customer.address,
            city         = p_customer.city,
            state        = p_customer.state,
            postal_code  = p_customer.postal_code,
            country      = p_customer.country
        where customer_id = p_customer.customer_id;
    elsif p_operation = 'delete' then
        delete
        from customers
        where customer_id = p_customer.customer_id;
    else
        DBMS_OUTPUT.PUT_LINE('Invalid operation provided. Valid operations are insert, update, and delete.');
    end if;
end;
/

