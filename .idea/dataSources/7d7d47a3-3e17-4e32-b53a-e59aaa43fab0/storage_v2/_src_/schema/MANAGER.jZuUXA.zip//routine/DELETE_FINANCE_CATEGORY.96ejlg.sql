create procedure delete_finance_category(p_category_id in finance_category.category_id%type) is
begin
    delete
    from finance_category
    where category_id = p_category_id;
end;
/

