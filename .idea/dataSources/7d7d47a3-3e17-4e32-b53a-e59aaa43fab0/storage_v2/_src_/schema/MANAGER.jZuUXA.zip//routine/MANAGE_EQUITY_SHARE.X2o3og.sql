create procedure manage_equity_share(p_operation in varchar2, p_equity equity_shares%rowtype) is
begin
    if lower(p_operation) = 'insert' then
        insert into equity_shares
        values p_equity;
    elsif lower(p_operation) = 'update' then
        update equity_shares
        set equity_name        = p_equity.equity_name,
            equity_category_id = p_equity.equity_category_id,
            quantity           = p_equity.quantity,
            purchase_date      = p_equity.purchase_date,
            purchase_price     = p_equity.purchase_price
        where equity_id = p_equity.equity_id;
    elsif lower(p_operation) = 'delete' then
        delete
        from equity_shares
        where equity_id = p_equity.equity_id;
    else
        DBMS_OUTPUT.PUT_LINE('Invalid operation provided. Valid operations are insert, update, and delete.');
    end if;
end;
/

