create procedure insert_insurance_master(p_insurance_master in insurance_master%rowtype) is
begin
    insert into insurance_master values p_insurance_master;
end;
/

