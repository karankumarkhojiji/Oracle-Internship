create procedure delete_insurance_master(p_insurance_master_id in insurance_master.insurance_id%type) is
begin
    delete
    from insurance_master
    where insurance_id = p_insurance_master_id;
end;
/

