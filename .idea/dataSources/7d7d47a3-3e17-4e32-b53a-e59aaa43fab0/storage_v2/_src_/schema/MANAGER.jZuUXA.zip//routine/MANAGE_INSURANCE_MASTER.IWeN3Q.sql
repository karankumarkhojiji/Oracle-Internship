create procedure manage_insurance_master(p_operation in varchar2, p_insurance_master in insurance_master%rowtype) is
begin
    if p_operation = 'insert' then
        insert into insurance_master
        values p_insurance_master;
    elsif p_operation = 'update' then
        update insurance_master
        set policy_number  = p_insurance_master.policy_number,
            insurance_type = p_insurance_master.insurance_type,
            premium_amount = p_insurance_master.premium_amount,
            start_date     = p_insurance_master.start_date,
            end_date       = p_insurance_master.end_date
        where insurance_id = p_insurance_master.insurance_id;
    elsif p_operation = 'delete' then
        delete from insurance_master
        where insurance_id = p_insurance_master.insurance_id;
    else
        DBMS_OUTPUT.PUT_LINE('Invalid operation provided. Valid operations are insert, update, and delete.');
    end if;
end;
/

