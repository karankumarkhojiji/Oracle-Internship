create procedure insert_customer(p_customer customers%rowtype) is
begin
    insert into customers
    values p_customer;
end;
/

