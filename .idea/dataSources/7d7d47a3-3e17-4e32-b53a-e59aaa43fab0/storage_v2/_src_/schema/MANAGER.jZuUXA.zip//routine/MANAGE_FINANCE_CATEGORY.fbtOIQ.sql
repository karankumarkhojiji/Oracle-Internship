create procedure manage_finance_category(p_operation in varchar2, p_category finance_category%rowtype) is
begin
    if trim(lower(p_operation)) = 'insert' then
        insert into finance_category
        values p_category;
    elsif trim(lower(p_operation)) = 'update' then
        update finance_category
        set category_name = trim(p_category.category_name)
        where category_id = trim(p_category.category_id);
    elsif trim(lower(p_operation)) = 'delete' then
        delete
        from finance_category
        where category_id = trim(p_category.category_id);
    else
        DBMS_OUTPUT.PUT_LINE('Invalid operation provided. Valid operations are insert, update, and delete.');
    end if;
end;
/

