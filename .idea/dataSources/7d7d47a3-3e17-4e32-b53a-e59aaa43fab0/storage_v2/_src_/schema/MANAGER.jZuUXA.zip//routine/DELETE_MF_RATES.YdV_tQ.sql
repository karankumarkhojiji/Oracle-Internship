create procedure delete_mf_rates(p_mf_rates_id in mf_rates.mf_id%type) is
begin
    delete
    from mf_rates
    where rate_id = p_mf_rates_id;
end;
/

