create procedure update_equity_rate(p_rate in equity_rate%rowtype) is
begin
    update equity_rate
    set equity_id     = p_rate.equity_id,
        rate_date     = p_rate.rate_date,
        closing_price = p_rate.closing_price
    where rate_id = p_rate.rate_id;
end;
/

