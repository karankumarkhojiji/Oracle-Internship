create procedure manage_transaction(p_operation in varchar2, p_transaction in transactions%rowtype) is
begin
    if lower(p_operation) = 'insert' then
        insert into transactions
        values p_transaction;
    elsif lower(p_operation) = 'update' then
        update transactions
        set transactions_date = p_transaction.transactions_date,
            transactions_type = p_transaction.transactions_type,
            amount            = p_transaction.amount,
            customer_id       = p_transaction.customer_id,
            equity_id         = p_transaction.equity_id,
            mf_id             = p_transaction.mf_id,
            insurance_id      = p_transaction.insurance_id
        where transaction_id = p_transaction.transaction_id;
    elsif lower(p_operation) = 'delete' then
        delete from transactions
        where transaction_id = p_transaction.transaction_id;
    else
        DBMS_OUTPUT.PUT_LINE('Invalid operation provided. Valid operations are insert, update, and delete.');
    end if;
end;
/

