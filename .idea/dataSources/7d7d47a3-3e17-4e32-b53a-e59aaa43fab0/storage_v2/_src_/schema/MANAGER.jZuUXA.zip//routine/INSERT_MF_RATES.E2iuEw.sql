create procedure insert_mf_rates(p_mf_rates in mf_rates%rowtype) is
begin
    insert into mf_rates values p_mf_rates;
end;
/

