create procedure delete_transaction(p_transaction_id in transactions.transaction_id%type) is
begin
    delete
    from transactions
    where transaction_id = p_transaction_id;
end;
/

