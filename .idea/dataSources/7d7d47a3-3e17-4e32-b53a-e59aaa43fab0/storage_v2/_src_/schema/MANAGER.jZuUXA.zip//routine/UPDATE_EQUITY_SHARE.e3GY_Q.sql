create procedure update_equity_share(p_equity equity_shares%rowtype) is
begin
    update equity_shares
    set equity_name        = p_equity.equity_name,
        equity_category_id = p_equity.equity_category_id,
        quantity           = p_equity.quantity,
        purchase_date      = p_equity.purchase_date,
        purchase_price     = p_equity.purchase_price
    where equity_id = p_equity.equity_id;
end;
/

