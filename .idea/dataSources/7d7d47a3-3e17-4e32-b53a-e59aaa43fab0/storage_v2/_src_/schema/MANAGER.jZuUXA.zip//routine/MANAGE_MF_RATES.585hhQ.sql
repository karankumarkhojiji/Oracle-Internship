create procedure manage_mf_rates(p_operation in varchar2, p_mf_rates in mf_rates%rowtype) is
begin
    if trim(lower(p_operation)) = 'insert' then
        insert into mf_rates
        values p_mf_rates;
    elsif trim(lower(p_operation)) = 'update' then
        update mf_rates
        set mf_id     = trim(p_mf_rates.mf_id),
            rate_date = trim(p_mf_rates.rate_date),
            nav       = trim(p_mf_rates.nav)
        where rate_id = trim(p_mf_rates.rate_id);
    elsif trim(lower(p_operation)) = 'delete' then
        delete
        from mf_rates
        where rate_id = trim(p_mf_rates.rate_id);
    else
        DBMS_OUTPUT.PUT_LINE('Invalid operation provided. Valid operations are insert, update, and delete.');
    end if;
end;
/

