create procedure manage_mf_rates(p_operation in varchar2, p_mf_rates in mf_rates%rowtype) is
begin
    if p_operation = 'insert' then
        insert into mf_rates
        values p_mf_rates;
    elsif p_operation = 'update' then
        update mf_rates
        set mf_id     = p_mf_rates.mf_id,
            rate_date = p_mf_rates.rate_date,
            nav       = p_mf_rates.nav
        where rate_id = p_mf_rates.rate_id;
    elsif p_operation = 'delete' then
        delete from mf_rates
        where rate_id = p_mf_rates.rate_id;
    else
        DBMS_OUTPUT.PUT_LINE('Invalid operation provided. Valid operations are insert, update, and delete.');
    end if;
end;
/

