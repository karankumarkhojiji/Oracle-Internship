create procedure update_finance_category(p_category finance_category%rowtype) is
begin
    update finance_category
    set category_name = p_category.category_name
    where category_id = p_category.category_id;
end;
/

