create procedure delete_equity_share(p_equity_id in equity_shares.equity_id%type) is
begin
    delete from equity_shares where equity_id = p_equity_id;
end;
/

