create procedure insert_finance_category(p_category finance_category%rowtype) is
begin
    insert into finance_category values p_category;
end;
/

