create procedure delete_mf_master(p_mf_master_id in mf_master.mf_id%type) is
begin
    delete
    from mf_master
    where mf_id = p_mf_master_id;
end;
/

