create procedure delete_equity_rate(p_rate_id in equity_rate.rate_id%type) is
begin
    delete
    from equity_rate
    where rate_id = p_rate_id;
end;
/

