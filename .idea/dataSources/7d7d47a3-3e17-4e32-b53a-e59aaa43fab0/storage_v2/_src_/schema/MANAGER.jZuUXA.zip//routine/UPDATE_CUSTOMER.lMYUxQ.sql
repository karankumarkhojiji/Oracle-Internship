create procedure update_customer(p_customer customers%rowtype) is
begin
    update customers
    set first_name   = p_customer.first_name,
        last_name    = p_customer.last_name,
        email        = p_customer.email,
        phone_number = p_customer.phone_number,
        address      = p_customer.address,
        city         = p_customer.city,
        state        = p_customer.state,
        postal_code  = p_customer.postal_code,
        country      = p_customer.country
    where customer_id = p_customer.customer_id;
end;
/

