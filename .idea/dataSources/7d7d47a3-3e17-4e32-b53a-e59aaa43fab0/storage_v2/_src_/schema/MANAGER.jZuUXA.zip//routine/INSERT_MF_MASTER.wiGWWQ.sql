create procedure insert_mf_master(p_mf_master in mf_master%rowtype) is
begin
    insert into mf_master values p_mf_master;
end;
/

