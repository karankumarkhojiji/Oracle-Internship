create procedure update_transaction(p_transaction in transactions%rowtype) is
begin
    update transactions
    set transactions_date = p_transaction.transactions_date,
        transactions_type = p_transaction.transactions_type,
        amount            = p_transaction.amount,
        customer_id       = p_transaction.customer_id,
        equity_id         = p_transaction.equity_id,
        mf_id             = p_transaction.mf_id,
        insurance_id      = p_transaction.insurance_id
    where insurance_id = p_transaction.insurance_id;
end;
/

