create procedure manage_mf_master(p_operation in varchar2, p_mf_master in mf_master%rowtype) is
begin
    if p_operation = 'insert' then
        insert into mf_master
        values p_mf_master;
    elsif p_operation = 'update' then
        update mf_master
        set mf_name         = p_mf_master.mf_name,
            mf_category_id  = p_mf_master.mf_category_id,
            fund_house      = p_mf_master.fund_house,
            inception_price = p_mf_master.inception_price
        where mf_id = p_mf_master.mf_id;
    elsif p_operation = 'delete' then
        delete from mf_master
        where mf_id = p_mf_master.mf_id;
    else
        DBMS_OUTPUT.PUT_LINE('Invalid operation provided. Valid operations are insert, update, and delete.');
    end if;
end;
/

