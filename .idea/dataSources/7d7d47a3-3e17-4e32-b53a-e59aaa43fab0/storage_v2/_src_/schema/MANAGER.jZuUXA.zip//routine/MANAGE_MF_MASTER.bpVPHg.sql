create procedure manage_mf_master(p_operation in varchar2, p_mf_master in mf_master%rowtype) is
begin
    if trim(lower(p_operation)) = 'insert' then
        insert into mf_master
        values p_mf_master;
    elsif trim(lower(p_operation)) = 'update' then
        update mf_master
        set mf_name         = trim(p_mf_master.mf_name),
            mf_category_id  = trim(p_mf_master.mf_category_id),
            fund_house      = trim(p_mf_master.fund_house),
            inception_date = trim(p_mf_master.inception_date)
        where mf_id = trim(p_mf_master.mf_id);
    elsif trim(lower(p_operation)) = 'delete' then
        delete
        from mf_master
        where mf_id = trim(p_mf_master.mf_id);
    else
        DBMS_OUTPUT.PUT_LINE('Invalid operation provided. Valid operations are insert, update, and delete.');
    end if;
end;
/

