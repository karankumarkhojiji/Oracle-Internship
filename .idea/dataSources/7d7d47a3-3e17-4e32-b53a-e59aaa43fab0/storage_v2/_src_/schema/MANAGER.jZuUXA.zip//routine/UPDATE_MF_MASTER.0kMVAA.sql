create procedure update_mf_master(p_mf_master in mf_master%rowtype) is
begin
    update mf_master
    set mf_name         = p_mf_master.mf_name,
        mf_category_id  = p_mf_master.mf_category_id,
        fund_house      = p_mf_master.fund_house,
        inception_price = p_mf_master.inception_price
    where mf_id = p_mf_master.mf_id;
end;
/

