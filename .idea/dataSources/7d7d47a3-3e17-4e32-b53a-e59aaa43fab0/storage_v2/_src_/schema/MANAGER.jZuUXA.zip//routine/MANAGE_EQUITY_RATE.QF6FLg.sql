create procedure manage_equity_rate(p_operation in varchar2, p_rate in equity_rate%rowtype) is
begin
    if p_operation = 'insert' then
        insert into equity_rate
        values p_rate;
    elsif p_operation = 'update' then
        update equity_rate
        set equity_id     = p_rate.equity_id,
            rate_date     = p_rate.rate_date,
            closing_price = p_rate.closing_price
        where rate_id = p_rate.rate_id;
    elsif p_operation = 'delete' then
        delete
        from equity_rate
        where rate_id = p_rate.rate_id;
    else
        DBMS_OUTPUT.PUT_LINE('Invalid operation provided. Valid operations are insert, update, and delete.');
    end if;
end;
/

