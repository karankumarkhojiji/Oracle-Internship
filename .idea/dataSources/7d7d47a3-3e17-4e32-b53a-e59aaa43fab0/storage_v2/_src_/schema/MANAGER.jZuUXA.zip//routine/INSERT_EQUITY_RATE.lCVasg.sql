create procedure insert_equity_rate(p_rate in equity_rate%rowtype) is
begin
    insert into equity_rate values p_rate;
end;
/

