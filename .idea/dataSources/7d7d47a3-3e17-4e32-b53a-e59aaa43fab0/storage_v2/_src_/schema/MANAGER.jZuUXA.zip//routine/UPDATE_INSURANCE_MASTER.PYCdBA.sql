create procedure update_insurance_master(p_insurance_master in insurance_master%rowtype) is
begin
    update insurance_master
    set policy_number  = p_insurance_master.policy_number,
        insurance_type = p_insurance_master.insurance_type,
        premium_amount = p_insurance_master.premium_amount,
        start_date     = p_insurance_master.start_date,
        end_date       = p_insurance_master.end_date
    where insurance_id = p_insurance_master.insurance_id;
end;
/

